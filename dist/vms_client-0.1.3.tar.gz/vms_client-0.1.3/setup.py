# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['vms_client']

package_data = \
{'': ['*']}

install_requires = \
['PyNaCl==1.4.0', 'click==8.0.1', 'python-dateutil==2.8.2', 'requests==2.26.0']

setup_kwargs = {
    'name': 'vms-client',
    'version': '0.1.3',
    'description': "VMS client for Exodus Intelligence's API.",
    'long_description': None,
    'author': 'DevTeam',
    'author_email': 'dev@exodusintel.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
